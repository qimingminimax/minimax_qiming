# -*- coding:utf-8 -*-
def add_num(a,b):
    return a+b
