# -*- coding:utf-8 -*-
from minimax_qiming.get_ua import get_mobile_ua
from minimax_qiming.get_ua import get_pc_ua
